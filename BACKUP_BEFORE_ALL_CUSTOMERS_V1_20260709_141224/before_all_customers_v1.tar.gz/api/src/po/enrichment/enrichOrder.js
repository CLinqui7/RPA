import { cleanMasterValue, loadMasterData, normalizeMasterToken } from './masterData.js';

function clean(value) {
  return cleanMasterValue(value);
}

function upper(value) {
  return clean(value).toUpperCase();
}

function unique(values) {
  return [...new Set(values.filter(Boolean))];
}

function candidateSummary(rows, limit = 8) {
  return rows.slice(0, limit).map((row) => ({
    style: clean(row.Style),
    color: clean(row.Clr),
    color_description: clean(row['Clr Desc']),
    sku: clean(row.Sku),
    div: clean(row.Div),
    customer: clean(row.Customer),
    scale: clean(row.Scale),
    scale_abbr: clean(row['Scale Abbr']),
    price: clean(row.Price)
  }));
}

function inferCustomer(parsed, masters) {
  const header = parsed.header || {};
  const current = upper(header.customer_code);
  if (current && masters.customerByCode.has(current)) return current;

  const parser = clean(parsed.parser).toLowerCase();
  if (parser === 'cititrends' && masters.customerByCode.has('CITI')) return 'CITI';
  if (parser === 'bealls' && masters.customerByCode.has('BEALLSOUTL')) return 'BEALLSOUTL';
  if (parser === 'ollies' && masters.customerByCode.has('OLLIES')) return 'OLLIES';
  if (parser === 'carnival' && masters.customerByCode.has('CARNIVAL')) return 'CARNIVAL';
  if (parser === 'tenbelow' && masters.customerByCode.has('10BELOW')) return '10BELOW';

  const rawKey = normalizeMasterToken(header.customer_raw);
  if (rawKey && masters.customerByName.has(rawKey)) return upper(masters.customerByName.get(rawKey).Customer);
  return current || null;
}

function applyCustomerMaster(parsed, masters, conflicts, trace) {
  const header = parsed.header || {};
  const customerCode = inferCustomer(parsed, masters);
  if (!customerCode) return null;

  const customer = masters.customerByCode.get(customerCode);
  if (!customer) return null;

  header.customer_code = header.customer_code || customerCode;
  header.raw = header.raw || {};
  const masterTerms = clean(customer.Terms);
  const previousTermsCode = clean(header.terms_code);
  header.raw.customer_master = {
    customer: customerCode,
    name: clean(customer['Cust Name']),
    terms: masterTerms,
    terms_description: clean(customer['Terms Description']),
    ship_via: clean(customer['Ship Via']),
    def_wh: clean(customer['Def Wh']),
    div: clean(customer.Div),
    address: [customer['Addr 1'], customer.City, customer.State, customer.Postal].map(clean).filter(Boolean).join(', '),
    terms_resolution: masterTerms ? {
      source: 'customer_master',
      code: masterTerms,
      pdf_terms_raw: clean(header.terms_raw) || null,
      comparison_mode: 'audit_only'
    } : null
  };

  // Customer Master is the authoritative source for A2000 TERM_NO once the
  // customer has been resolved. PDF terms remain raw audit evidence only.
  if (masterTerms) {
    header.terms_code = masterTerms;
    if (previousTermsCode && previousTermsCode !== masterTerms) {
      conflicts.push({
        field: 'terms_code',
        message: 'Existing terms code differs from Customer Master; Customer Master code was used.',
        previous: previousTermsCode,
        master: masterTerms
      });
    }
  }
  if (!header.ship_via_code && clean(customer['Ship Via'])) header.ship_via_code = clean(customer['Ship Via']);
  if (!header.warehouse_code && clean(customer['Def Wh'])) header.warehouse_code = clean(customer['Def Wh']);
  if (!header.division_code && clean(customer.Div)) header.division_code = clean(customer.Div);

  trace.customer = header.raw.customer_master;
  return customerCode;
}

function applyDefaultStore(parsed, masters, customerCode, trace) {
  const header = parsed.header || {};
  const parser = clean(parsed.parser).toLowerCase();

  // First resolve an exact printed store/DC number against the customer store master.
  // This preserves parser scope: the parser only captures store_raw; enrichment owns STORE_NO.
  if (!header.store_code && header.store_raw && customerCode) {
    const exactPrintedStore = masters.storeByCustomerStore.get(`${customerCode}|${upper(header.store_raw)}`);
    if (exactPrintedStore) {
      header.store_code = clean(exactPrintedStore.Store) || null;
      header.raw = header.raw || {};
      header.raw.store_master = {
        source: 'stores_master_exact_printed_store',
        customer: customerCode,
        store: clean(exactPrintedStore.Store),
        printed_store_raw: clean(header.store_raw),
        name: clean(exactPrintedStore['St Name']),
        address: [exactPrintedStore['St Addr 1'], exactPrintedStore['St City'], exactPrintedStore['St State'], exactPrintedStore['St Postal']].map(clean).filter(Boolean).join(', '),
        active: clean(exactPrintedStore.Active)
      };
      trace.store = header.raw.store_master;
    }
  }

  // User-approved rule: Citi PO does not print a store, so use Citi default office from stores_master.
  // This is not a PDF value. It is explicitly marked as master_default_office.
  if (parser === 'cititrends' && customerCode === 'CITI' && !header.store_code) {
    const defaultStore = masters.defaultStoreByCustomer.get(customerCode);
    if (defaultStore) {
      header.store_code = clean(defaultStore.Store) || null;
      header.store_raw = header.store_raw || clean(defaultStore['St Name']) || null;
      header.raw = header.raw || {};
      header.raw.store_master = {
        source: 'stores_master_default_office',
        customer: customerCode,
        store: clean(defaultStore.Store),
        name: clean(defaultStore['St Name']),
        address: [defaultStore['St Addr 1'], defaultStore['St City'], defaultStore['St State'], defaultStore['St Postal']].map(clean).filter(Boolean).join(', '),
        active: clean(defaultStore.Active)
      };
      trace.store = header.raw.store_master;
    }
  }

  if (header.store_code && customerCode) {
    const store = masters.storeByCustomerStore.get(`${customerCode}|${upper(header.store_code)}`);
    if (store) {
      header.raw = header.raw || {};
      header.raw.store_master = header.raw.store_master || {
        source: 'stores_master_exact',
        customer: customerCode,
        store: clean(store.Store),
        name: clean(store['St Name']),
        address: [store['St Addr 1'], store['St City'], store['St State'], store['St Postal']].map(clean).filter(Boolean).join(', '),
        active: clean(store.Active)
      };
      if (!header.ship_via_code && clean(store['Ship Via'])) header.ship_via_code = clean(store['Ship Via']);
      if (!header.warehouse_code && clean(store.Wh)) header.warehouse_code = clean(store.Wh);
    }
  }
}


function styleRowsForStyle(masters, styleCode) {
  return masters.skuByStyle.get(upper(styleCode)) || [];
}

function inferStyleFromMaster({ masters, customerCode, styleRaw, description }) {
  const rawToken = normalizeMasterToken(styleRaw);
  if (!rawToken) return { style_code: null, candidates: [] };

  const searchCustomers = unique([customerCode, 'STOCK']);
  const styles = new Set();

  for (const customer of searchCustomers) {
    const direct = masters.styleByCustomerNorm.get(`${customer}|${rawToken}`);
    if (direct) direct.forEach((style) => styles.add(style));
  }

  // Fuzzy but bounded: only scan styles already in the index by exact normalized fields.
  // For Citi JANICET, Master Style JANICE-T normalizes to JANICET, so this usually hits above.
  if (!styles.size && description) {
    const descToken = normalizeMasterToken(description).slice(0, 16);
    if (descToken) {
      for (const [key, set] of masters.styleByCustomerNorm.entries()) {
        const [customer, token] = key.split('|');
        if (!searchCustomers.includes(customer)) continue;
        if (token.includes(rawToken) || rawToken.includes(token) || token.includes(descToken)) {
          set.forEach((style) => styles.add(style));
        }
      }
    }
  }

  const candidates = [...styles].flatMap((style) => styleRowsForStyle(masters, style));
  const uniqueStyles = unique([...styles]);
  return {
    style_code: uniqueStyles.length === 1 ? uniqueStyles[0] : null,
    candidates
  };
}

function colorMatches(row, colorRaw, description) {
  const color = normalizeMasterToken(colorRaw);
  const desc = normalizeMasterToken(description);
  const rowTokens = [row.Clr, row['Clr Desc'], row['Clr Abbr'], row['Nrf Color']].map(normalizeMasterToken).filter(Boolean);
  if (!color && !desc) return false;
  if (color && rowTokens.some((token) => token === color || token.includes(color) || color.includes(token))) return true;
  if (desc && rowTokens.some((token) => desc.includes(token) || token.includes(desc))) return true;
  return false;
}


function rowForColor(styleRows, colorCode, customerCode) {
  const code = upper(colorCode);
  const customer = upper(customerCode);
  const rows = styleRows.filter((row) => upper(row.Clr) === code);
  if (!rows.length) return null;
  return rows.find((row) => upper(row.Customer) === customer)
    || rows.find((row) => upper(row.Customer) === 'STOCK')
    || rows[0];
}

function isAlpha3ColorCode(value) {
  return /^[A-Z]{3}$/.test(upper(value));
}

function preferredRowForCustomer(rows, customerCode) {
  const customer = upper(customerCode);
  return rows.find((row) => upper(row.Customer) === customer)
    || rows.find((row) => upper(row.Customer) === 'STOCK')
    || rows[0]
    || null;
}

function singleAlpha3ColorCandidate(rows, customerCode) {
  const byColor = new Map();
  for (const row of rows || []) {
    const code = upper(row.Clr);
    if (!isAlpha3ColorCode(code)) continue;
    if (!byColor.has(code)) byColor.set(code, []);
    byColor.get(code).push(row);
  }

  const colors = [...byColor.keys()];
  if (colors.length !== 1) {
    return { color_code: null, row: null, candidates: colors };
  }

  const color = colors[0];
  return {
    color_code: color,
    row: preferredRowForCustomer(byColor.get(color), customerCode),
    candidates: colors
  };
}

const COLOR_FAMILY_PATTERNS = [
  { family: 'BLACK_OFF_BLACK', tests: ['BLACKOFFBLACK', 'BLACKOFB', 'BLKOFFBLACK', 'OFFBLACK'] },
  { family: 'PINK_BLACK', tests: ['PINKBLACK', 'PNKBLACK'] },
  { family: 'RED_BLACK', tests: ['REDBLACK'] },
  { family: 'WHITE', tests: ['WHITE', 'WHT'] },
  { family: 'BLACK', tests: ['BLACK', 'BLK'] },
  { family: 'PINK', tests: ['PINK', 'PNK'] },
  { family: 'TAUPE', tests: ['TAUPE', 'TPE'] },
  { family: 'KHAKI', tests: ['KHAKI', 'KHA'] },
  { family: 'DOVE', tests: ['DOVE'] },
  { family: 'TAN', tests: ['TAN'] },
  { family: 'BROWN', tests: ['BROWN', 'BRN'] },
  { family: 'NAVY', tests: ['NAVY', 'NVY'] },
  { family: 'BLUE', tests: ['BLUE', 'BLU'] },
  { family: 'GREEN', tests: ['GREEN', 'GRN'] },
  { family: 'GRAY', tests: ['GRAY', 'GREY', 'GRY'] },
  { family: 'RED', tests: ['RED'] },
  { family: 'PURPLE', tests: ['PURPLE', 'PRP'] },
  { family: 'ORANGE', tests: ['ORANGE', 'ORG'] },
  { family: 'YELLOW', tests: ['YELLOW', 'YLW'] },
  { family: 'IVORY', tests: ['IVORY', 'IVY'] },
  { family: 'CREAM', tests: ['CREAM', 'CRM'] },
  { family: 'GOLD', tests: ['GOLD', 'GLD'] },
  { family: 'SILVER', tests: ['SILVER', 'SLV'] },
  { family: 'MULTI', tests: ['MULTI', 'MULTICOLOR', 'MULTI COLOR'] }
];

const CUSTOMER_COLOR_PREFERENCES = {
  // User-approved Citi preferences. These are applied only when the printed color text
  // matches the family AND the chosen code exists for the matched style in the master.
  CITI: {
    WHITE: ['WTB', 'WHA', '001', '076'],
    BLACK_OFF_BLACK: ['BKA', 'BCB', '96A', '003'],
    BLACK: ['BKA', '003', 'BCB', '96A'],
    PINK: ['PKA', '009'],
    TAUPE: ['TA2'],
    KHAKI: ['KHA'],
    DOVE: ['DOV', 'AD9'],
    TAN: ['TAN', 'TNA'],
    NAVY: ['NVY'],
    BLUE: ['BLU'],
    RED: ['RED'],
    MULTI: ['MUL']
  },
  BEALLSOUTL: {
    BLACK: ['003'],
    BLACK_OFF_BLACK: ['003'],
    PINK_BLACK: ['89K'],
    RED_BLACK: ['410'],
    KHAKI: ['KHA'],
    DOVE: ['AD9']
  }
};

function detectPrintedColorFamilies(line) {
  const text = normalizeMasterToken([line.color_raw, line.description, line.raw?.style_line, line.raw?.detail_line].filter(Boolean).join(' '));
  if (!text) return [];

  const found = [];
  for (const pattern of COLOR_FAMILY_PATTERNS) {
    if (pattern.tests.some((token) => text.includes(token))) found.push({ family: pattern.family, text });
  }

  // Keep the strongest family first. Example: BLACK-OFF BLACK should not be reduced to plain BLACK.
  const priority = ['BLACK_OFF_BLACK', 'PINK_BLACK', 'RED_BLACK', 'WHITE', 'BLACK', 'PINK', 'TAUPE', 'KHAKI', 'DOVE', 'TAN', 'BROWN', 'NAVY', 'BLUE', 'GREEN', 'GRAY', 'RED', 'PURPLE', 'ORANGE', 'YELLOW', 'IVORY', 'CREAM', 'GOLD', 'SILVER', 'MULTI'];
  return found.sort((a, b) => priority.indexOf(a.family) - priority.indexOf(b.family));
}

function rowsMatchingColorFamily(styleRows, family) {
  const familyText = normalizeMasterToken(family.replace(/_/g, ' '));
  const compactFamily = normalizeMasterToken(family);
  return styleRows.filter((row) => {
    const rowTokens = [row.Clr, row['Clr Desc'], row['Clr Abbr'], row['Nrf Color']].map(normalizeMasterToken).filter(Boolean);
    if (family === 'BLACK_OFF_BLACK') {
      return rowTokens.some((token) => ['BLACK', 'BLACK2', 'OFFBLACK'].some((word) => token.includes(word) || word.includes(token)));
    }
    if (family === 'PINK_BLACK') {
      return rowTokens.some((token) => token.includes('PINK') || token.includes('BLACK'));
    }
    if (family === 'RED_BLACK') {
      return rowTokens.some((token) => token.includes('RED') || token.includes('BLACK'));
    }
    return rowTokens.some((token) => token === familyText || token === compactFamily || token.includes(familyText) || familyText.includes(token));
  });
}

function inferCustomerColorAlias({ parsed, customerCode, line, styleRows }) {
  const customer = upper(customerCode);
  if (!styleRows.length) return { color_code: null, row: null, reason: null, confidence: 0, family: null };

  const families = detectPrintedColorFamilies(line);
  if (!families.length) return { color_code: null, row: null, reason: null, confidence: 0, family: null };

  for (const detected of families) {
    const family = detected.family;
    const preferences = CUSTOMER_COLOR_PREFERENCES[customer]?.[family] || [];

    // 1) Customer-approved preference wins, but only if the color code exists for this style.
    for (const code of preferences) {
      const row = rowForColor(styleRows, code, customer);
      if (row) {
        return {
          color_code: upper(code),
          row,
          reason: `customer_color_preference_${customer.toLowerCase()}_${family.toLowerCase()}_to_${upper(code).toLowerCase()}`,
          confidence: 0.95,
          family
        };
      }
    }

    // 2) Generic A2000 color-code convention: when a printed color maps to multiple
    // master rows, prefer a single 3-letter alphabetic color code over numeric or mixed
    // codes. This is still validated against the matched style rows. If there are two
    // 3-letter choices, keep it unresolved unless a customer preference above selected one.
    const familyRows = rowsMatchingColorFamily(styleRows, family);
    const alpha3 = singleAlpha3ColorCandidate(familyRows, customer);
    if (alpha3.color_code && alpha3.row) {
      return {
        color_code: alpha3.color_code,
        row: alpha3.row,
        reason: `alpha3_master_color_preference_${family.toLowerCase()}_to_${alpha3.color_code.toLowerCase()}`,
        confidence: 0.78,
        family
      };
    }

    // 3) If no preference or alpha-3 convention resolves it, use the master itself.
    // Accept only when the color family produces one unique color for the matched style.
    // Otherwise keep it unresolved and expose candidates in raw.color_master_candidates.
    const colors = unique(familyRows.map((row) => upper(row.Clr)));
    if (colors.length === 1) {
      const row = rowForColor(styleRows, colors[0], customer) || familyRows[0];
      return {
        color_code: colors[0],
        row,
        reason: `single_master_color_match_${family.toLowerCase()}_to_${colors[0].toLowerCase()}`,
        confidence: 0.82,
        family
      };
    }
  }

  return { color_code: null, row: null, reason: 'ambiguous_printed_color', confidence: 0, family: families[0]?.family || null };
}

function inferColorFromMaster({ styleRows, colorRaw, description }) {
  const matches = styleRows.filter((row) => colorMatches(row, colorRaw, description));
  const colors = unique(matches.map((row) => upper(row.Clr)));
  return {
    color_code: colors.length === 1 ? colors[0] : null,
    candidates: matches.length ? matches : styleRows
  };
}

function findSkuRow(masters, styleCode, colorCode, customerCode) {
  if (!styleCode || !colorCode) return null;
  const style = upper(styleCode);
  const color = upper(colorCode);
  const customer = upper(customerCode);
  const rows = (masters.skuByStyle.get(style) || []).filter((row) => upper(row.Clr) === color);
  if (rows.length) {
    return rows.find((row) => upper(row.Customer) === customer)
      || rows.find((row) => upper(row.Customer) === 'STOCK')
      || rows[0];
  }
  return masters.skuByStyleColor.get(`${style}|${color}`) || null;
}

function findMasterUpc(masters, styleCode, colorCode, sizeRaw) {
  if (!styleCode || !colorCode) return { upc: null, row: null, candidates: [] };
  const style = upper(styleCode);
  const color = upper(colorCode);
  const size = normalizeMasterToken(sizeRaw === '-' ? 'PC' : sizeRaw);
  const exact = size ? masters.upcByStyleColorSize.get(`${style}|${color}|${size}`) || [] : [];
  const candidates = exact.length ? exact : (masters.upcByStyleColor.get(`${style}|${color}`) || []);
  if (!candidates.length) return { upc: null, row: null, candidates: [] };

  const pc = candidates.find((row) => normalizeMasterToken(row['Size Name']) === 'PC' || normalizeMasterToken(row.Scale) === 'PC') || null;
  const row = pc || (candidates.length === 1 ? candidates[0] : null);
  return { upc: row ? clean(row['Upc No']) : null, row, candidates };
}

function normalizeUpcValue(value) {
  const digits = clean(value).replace(/[^0-9]/g, '');
  return /^\d{11,14}$/.test(digits) ? digits : '';
}

function resolveExactUpc({ masters, line }) {
  const inputValues = unique([
    line.customer_upc,
    line.upc,
    line.raw?.customer_upc_raw
  ].map(normalizeUpcValue));

  let firstAmbiguous = null;
  for (const upc of inputValues) {
    const candidates = masters.upcByValue?.get(upc) || [];
    if (!candidates.length) continue;

    if (candidates.length === 1) {
      return { upc, row: candidates[0], candidates, reason: 'exact_upc_unique' };
    }

    const rawStyle = normalizeMasterToken(line.style_raw);
    if (rawStyle) {
      const styleMatches = candidates.filter((row) => normalizeMasterToken(row.Style) === rawStyle);
      if (styleMatches.length === 1) {
        return { upc, row: styleMatches[0], candidates, reason: 'exact_upc_style_disambiguated' };
      }
    }

    // Duplicate master rows are harmless only when the complete business tuple
    // is identical. Division, scale and SKU are part of the tuple because A2000
    // validates combinations, not isolated codes.
    const tupleMap = new Map();
    for (const row of candidates) {
      const key = [
        upper(row.Style),
        upper(row.Clr),
        clean(row['Size Num']),
        upper(row['Size Name']),
        upper(row.Div),
        upper(row.Scale),
        upper(row.Sku)
      ].join('|');
      if (!tupleMap.has(key)) tupleMap.set(key, row);
    }
    if (tupleMap.size === 1) {
      return { upc, row: [...tupleMap.values()][0], candidates, reason: 'exact_upc_duplicate_rows_same_business_tuple' };
    }

    firstAmbiguous ||= { upc, row: null, candidates, reason: 'exact_upc_ambiguous' };
  }

  return firstAmbiguous || { upc: null, row: null, candidates: [], reason: null };
}

function resolveCompositeStyleSuffix({ masters, customerCode, styleRaw }) {
  const printed = clean(styleRaw).toUpperCase();
  const match = printed.match(/^(.+)-([A-Z0-9]{2,8})$/);
  if (!match) return { style_code: null, color_code: null, row: null, candidates: [], reason: null };

  const baseStyle = clean(match[1]).toUpperCase();
  const suffix = clean(match[2]).toUpperCase();
  const styleRows = styleRowsForStyle(masters, baseStyle);
  if (!styleRows.length) {
    return { style_code: null, color_code: null, row: null, candidates: [], reason: 'base_style_not_on_master' };
  }

  const exactColorRows = styleRows.filter((row) => upper(row.Clr) === suffix);
  if (!exactColorRows.length) {
    return { style_code: null, color_code: null, row: null, candidates: styleRows, reason: 'suffix_not_exact_color_for_style' };
  }

  const row = preferredRowForCustomer(exactColorRows, customerCode);
  return {
    style_code: baseStyle,
    color_code: suffix,
    row,
    candidates: exactColorRows,
    reason: 'exact_master_style_suffix_color'
  };
}

function applyExactUpcResolution(line, raw, resolution) {
  const row = resolution.row;
  if (!row) return;

  const printedStyle = clean(line.style_raw) || null;
  const resolvedStyle = clean(row.Style) || null;
  const resolvedColor = clean(row.Clr) || null;
  line.style_code = resolvedStyle;
  line.color_code = resolvedColor;
  line.master_upc = clean(row['Upc No']) || resolution.upc || null;
  line.internal_sku = line.internal_sku || clean(row.Sku) || null;
  line.master_sku = line.master_sku || clean(row.Sku) || null;
  line.master_division_code = line.master_division_code || clean(row.Div) || null;
  line.size_code = line.size_code || clean(row['Size Name']) || null;
  line.scale_code = line.scale_code || clean(row.Scale) || null;
  line.scale_abbr = line.scale_abbr || clean(row['Scale Abbr']) || null;
  if (line.list_price === null || line.list_price === undefined) {
    const price = Number(clean(row.Price));
    if (Number.isFinite(price) && clean(row.Price) !== '') line.list_price = price;
  }

  const sizeNum = Number.parseInt(clean(row['Size Num']), 10);
  const hasExistingBucket = Array.from({ length: 18 }, (_, index) => line[`qty_sz${index + 1}`])
    .some((value) => value !== null && value !== undefined && value !== '');
  const quantitySemantics = clean(raw.quantity_semantics).toUpperCase();
  const qtyTotal = Number(line.qty_total);
  const canAssignPrintedEachQty = quantitySemantics === 'EACH'
    && Number.isFinite(qtyTotal)
    && qtyTotal >= 0;

  if (!hasExistingBucket && Number.isInteger(sizeNum) && sizeNum >= 1 && sizeNum <= 18 && canAssignPrintedEachQty) {
    line[`qty_sz${sizeNum}`] = line.qty_total;
    raw.qty_bucket_resolution = {
      source: 'VR_UPC_STYLE_EXACT_UPC_SIZE_NUM',
      size_num: sizeNum,
      size_name: clean(row['Size Name']) || null,
      scale: clean(row.Scale) || null,
      quantity: line.qty_total,
      quantity_semantics: quantitySemantics
    };
  } else if (!hasExistingBucket && Number.isInteger(sizeNum) && sizeNum >= 1 && sizeNum <= 18 && line.qty_total !== null && line.qty_total !== undefined) {
    raw.qty_bucket_resolution = {
      source: 'VR_UPC_STYLE_EXACT_UPC_SIZE_NUM',
      status: 'not_applied',
      reason: 'quantity_semantics_not_each',
      size_num: sizeNum,
      size_name: clean(row['Size Name']) || null,
      scale: clean(row.Scale) || null,
      quantity: line.qty_total,
      quantity_semantics: quantitySemantics || null
    };
  }

  raw.upc_resolution = {
    source: 'VR_UPC_STYLE_EXACT_UPC',
    reason: resolution.reason,
    lookup_value: resolution.upc,
    candidate_count: resolution.candidates.length,
    style: resolvedStyle,
    color: resolvedColor,
    size_num: clean(row['Size Num']) || null,
    size_name: clean(row['Size Name']) || null,
    scale: clean(row.Scale) || null,
    div: clean(row.Div) || null,
    sku: clean(row.Sku) || null
  };

  if (printedStyle && resolvedStyle && normalizeMasterToken(printedStyle) !== normalizeMasterToken(resolvedStyle)) {
    raw.style_master_override = {
      source: 'VR_UPC_STYLE_EXACT_UPC',
      pdf_style_raw: printedStyle,
      master_style: resolvedStyle,
      note: 'Printed model/style differs from exact UPC master style; exact UPC mapping has priority in enrichment.'
    };
  }
}

function enrichLine(line, parsed, masters, customerCode, conflicts) {
  const parser = clean(parsed.parser).toLowerCase();
  const raw = { ...(line.raw || {}) };
  const explicitCustomerUpc = line.customer_upc || line.upc || null;

  // ticket_sku is a customer/document identifier in several legacy parsers and is
  // NOT semantically equivalent to UPC. Only explicit UPC fields may populate
  // customer_upc. This prevents accidental cross-identifier mapping.
  if (explicitCustomerUpc) {
    line.customer_upc = explicitCustomerUpc;
    raw.customer_upc_source = raw.customer_upc_source || 'explicit_pdf_upc';
  }

  // Exact reverse UPC resolution is opt-in by parser/document semantics. This
  // prevents a numeric ticket SKU from being mistaken for a UPC in other customers.
  const exactUpcAllowed = parser === 'ollies' || upper(raw.upc_semantics) === 'UPC';
  const exactUpc = exactUpcAllowed
    ? resolveExactUpc({ masters, line })
    : { upc: null, row: null, candidates: [], reason: null };
  if (exactUpc.row) {
    applyExactUpcResolution(line, raw, exactUpc);
  } else if (exactUpc.candidates.length) {
    raw.upc_master_candidates = exactUpc.candidates.slice(0, 10).map((row) => ({
      upc: clean(row['Upc No']),
      style: clean(row.Style),
      color: clean(row.Clr),
      size_num: clean(row['Size Num']),
      size_name: clean(row['Size Name']),
      scale: clean(row.Scale),
      sku: clean(row.Sku)
    }));
    raw.upc_resolution = {
      source: 'VR_UPC_STYLE_EXACT_UPC',
      reason: exactUpc.reason,
      lookup_value: exactUpc.upc,
      candidate_count: exactUpc.candidates.length
    };
  }

  // Composite printed vendor style, e.g. WILLA01L-SGA:
  // split only when BASE STYLE exists and SUFFIX is an exact COLOR code for that style.
  // This is enrichment validation against masters, never a blind parser hyphen rule.
  if (!exactUpc.row && parser === 'tenbelow' && line.style_raw) {
    const composite = resolveCompositeStyleSuffix({ masters, customerCode, styleRaw: line.style_raw });
    if (composite.style_code && composite.color_code) {
      line.style_code = composite.style_code;
      line.color_code = composite.color_code;
      raw.composite_style_resolution = {
        source: 'VR_SKU_EXACT_STYLE_COLOR_PAIR',
        reason: composite.reason,
        printed_style_raw: clean(line.style_raw),
        base_style: composite.style_code,
        suffix_color: composite.color_code,
        candidate_count: composite.candidates.length
      };
    } else {
      raw.composite_style_resolution = {
        source: 'VR_SKU_EXACT_STYLE_COLOR_PAIR',
        reason: composite.reason,
        printed_style_raw: clean(line.style_raw),
        base_style_candidate: clean(line.raw?.style_base_candidate_raw) || null,
        suffix_candidate: clean(line.raw?.style_suffix_candidate_raw) || null,
        candidate_count: composite.candidates.length
      };
    }
  }

  // Bealls already parses style/color from the PO. Citi usually needs style/color master help.
  if (!line.style_code) {
    const inferred = inferStyleFromMaster({ masters, customerCode, styleRaw: line.style_raw, description: line.description });
    if (inferred.style_code) line.style_code = inferred.style_code;
    raw.style_master_candidates = candidateSummary(inferred.candidates);
  }

  const styleRows = line.style_code ? styleRowsForStyle(masters, line.style_code) : [];

  if (!line.color_code && styleRows.length) {
    const aliasColor = inferCustomerColorAlias({ parsed, customerCode, line, styleRows });
    if (aliasColor.color_code) {
      line.color_code = aliasColor.color_code;
      raw.color_match_rule = aliasColor.reason;
      raw.color_match_family = aliasColor.family || null;
      raw.color_match_confidence = aliasColor.confidence || null;
      raw.color_master_candidates = candidateSummary([aliasColor.row]);
    } else {
      if (aliasColor.reason) {
        raw.color_match_rule = aliasColor.reason;
        raw.color_match_family = aliasColor.family || null;
      }
      const inferredColor = inferColorFromMaster({ styleRows, colorRaw: line.color_raw, description: line.description });
      if (inferredColor.color_code) line.color_code = inferredColor.color_code;
      raw.color_master_candidates = candidateSummary(inferredColor.candidates);
    }
  }

  const skuRow = findSkuRow(masters, line.style_code, line.color_code, customerCode);
  if (skuRow) {
    line.internal_sku = line.internal_sku || clean(skuRow.Sku) || null;
    line.master_sku = line.master_sku || clean(skuRow.Sku) || null;
    line.master_price = line.master_price || Number(clean(skuRow.Price)) || null;
    line.master_division_code = line.master_division_code || clean(skuRow.Div) || null;
    line.warehouse_code = line.warehouse_code || clean(skuRow.Wh) || null;
    line.scale_code = line.scale_code || clean(skuRow.Scale) || null;
    line.scale_abbr = line.scale_abbr || clean(skuRow['Scale Abbr']) || null;
    if ((line.list_price === null || line.list_price === undefined) && clean(skuRow.Price)) {
      const listPrice = Number(clean(skuRow.Price));
      if (Number.isFinite(listPrice)) line.list_price = listPrice;
    }
    if (!line.description && clean(skuRow['Sku Descr'])) line.description = clean(skuRow['Sku Descr']);
    raw.sku_master = {
      style: clean(skuRow.Style),
      color: clean(skuRow.Clr),
      color_description: clean(skuRow['Clr Desc']),
      color_abbr: clean(skuRow['Clr Abbr']),
      sku: clean(skuRow.Sku),
      div: clean(skuRow.Div),
      customer: clean(skuRow.Customer),
      price: clean(skuRow.Price),
      pack_qty: clean(skuRow['Pack Qty']),
      warehouse: clean(skuRow.Wh),
      scale: clean(skuRow.Scale),
      scale_abbr: clean(skuRow['Scale Abbr'])
    };
  }

  const upc = findMasterUpc(masters, line.style_code, line.color_code, line.size_raw || line.size_code);
  if (upc.upc) {
    line.master_upc = upc.upc;
    // Only fill ticket_sku from master when the document did not already print a UPC.
    if (!line.ticket_sku) line.ticket_sku = upc.upc;
    raw.upc_master = {
      upc: upc.upc,
      style: clean(upc.row?.Style),
      color: clean(upc.row?.Clr),
      size_name: clean(upc.row?.['Size Name']),
      div: clean(upc.row?.Div),
      sku: clean(upc.row?.Sku)
    };
  } else if (line.style_code && line.color_code) {
    raw.upc_master_candidates = (upc.candidates || []).slice(0, 10).map((row) => ({
      upc: clean(row['Upc No']),
      style: clean(row.Style),
      color: clean(row.Clr),
      size_name: clean(row['Size Name']),
      sku: clean(row.Sku)
    }));
  }

  // If all style/color rows agree on division, use it at header level later.
  if (!line.master_division_code && styleRows.length) {
    const divisions = unique(styleRows.map((row) => clean(row.Div)));
    if (divisions.length === 1) line.master_division_code = divisions[0];
  }

  if (parser === 'cititrends' && line.customer_upc && line.master_upc && line.customer_upc !== line.master_upc) {
    raw.upc_note = 'Citi printed UPC is kept as customer_upc. Master UPC is stored separately and does not overwrite the invoice UPC.';
  }

  line.raw = raw;
  return line;
}

function applyHeaderFromLines(parsed) {
  const header = parsed.header || {};
  const lineDivisions = unique((parsed.lines || []).map((line) => line.master_division_code || line.division_code));
  if (!header.division_code && lineDivisions.length === 1) header.division_code = lineDivisions[0];

  const lineWarehouses = unique((parsed.lines || []).map((line) => clean(line.warehouse_code)));
  if (!header.warehouse_code && lineWarehouses.length === 1) header.warehouse_code = lineWarehouses[0];
}

export function enrichOrderWithMasters(parsed) {
  if (process.env.A2000_MASTER_ENRICH === 'false') return parsed;

  const masters = loadMasterData();
  parsed.raw_enrichment = parsed.raw_enrichment || {};
  parsed.raw_enrichment.master_lookup = {
    attempted: true,
    master_dir: masters.masterDir,
    loaded: masters.loaded,
    counts: masters.counts,
    error: masters.error || null
  };

  if (!masters.loaded || masters.error) return parsed;

  const conflicts = parsed.conflicts || [];
  const trace = {};
  const customerCode = applyCustomerMaster(parsed, masters, conflicts, trace);
  applyDefaultStore(parsed, masters, customerCode, trace);

  parsed.lines = (parsed.lines || []).map((line) => enrichLine(line, parsed, masters, customerCode, conflicts));
  applyHeaderFromLines(parsed);

  parsed.conflicts = conflicts;
  parsed.raw_enrichment.master_lookup.trace = trace;
  return parsed;
}
