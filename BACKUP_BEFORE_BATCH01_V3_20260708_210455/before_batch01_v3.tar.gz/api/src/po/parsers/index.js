import { compactText, missingFields, inferStatus } from '../helpers.js';
import { normalizeForA2000 } from '../mappers/normalizeForA2000.js';
import { enrichOrderWithMasters } from '../enrichment/enrichOrder.js';
import { parseBealls } from './bealls.js';
import { parseGabes } from './gabes.js';
import { parseCitiTrends } from './cititrends.js';
import { parseSpencers } from './spencers.js';
import { parseVariety } from './variety.js';
import { parseShoeShow } from './shoeshow.js';
import { parseOllies } from './ollies.js';
import { parseCarnival } from './carnival.js';
import { parseTenBelow } from './tenbelow.js';

function detectCustomer({ text, fileName }) {
  const sample = compactText(`${fileName || ''} ${text || ''}`).toLowerCase();

  // Strict document-family anchors for raw parsers. Avoid generic logo-only matching.
  if (sample.includes("ollie's bargain outlet") && sample.includes('po#:') && sample.includes('upc number') && sample.includes('model#')) return 'ollies';
  if (sample.includes('carnival cruise line') && sample.includes('purchase order no') && sample.includes('date ordered') && sample.includes('item number')) return 'carnival';
  if ((sample.includes('10 below llc') || sample.includes('simply 10')) && sample.includes('purchase #') && sample.includes('vendor style') && sample.includes('total units')) return 'tenbelow';

  if (sample.includes('bealls') || sample.includes('beall blvd') || /dept#\d+\s*-po#/i.test(fileName || '')) return 'bealls';
  if (sample.includes("gabe's") || sample.includes('gabes.net') || sample.includes('gabrielap@gabes')) return 'gabes';
  if (sample.includes('cititrends.com') || sample.includes('citi trends')) return 'cititrends';
  if (sample.includes('spencer gifts') || sample.includes('sgvendors.com')) return 'spencers';
  if (sample.includes('shoe show') || sample.includes('purchase order #') && sample.includes('pattern:')) return 'shoeshow';
  if (sample.includes('variety wholesalers') || sample.includes('variety who') || sample.includes('vw sku') || sample.includes('vnd id')) return 'variety';
  return 'generic';
}

function genericParsedDocument() {
  return {
    parser: 'generic',
    document_family: 'unknown',
    layout_version: null,
    document_identity: {
      legal_entity_raw: null,
      brand_raw: null,
      customer_candidate: null,
      customer_candidate_source: null,
      a2000_customer_code: null
    },
    confidence: 0.1,
    header: {
      customer_raw: null,
      customer_code: null,
      order_no: null,
      order_date: null,
      start_date: null,
      cancel_date: null,
      book_date: null,
      dept_raw: null,
      dept_code: null,
      division_code: null,
      store_raw: null,
      store_code: null,
      terms_raw: null,
      terms_code: null,
      ship_via_code: null,
      warehouse_code: null,
      raw: {}
    },
    lines: [],
    totals: {},
    conflicts: [{ field: 'customer', message: 'No parser matched this document yet' }]
  };
}

export function parseRawPurchaseOrder({ text, fileName, document }) {
  const customer = detectCustomer({ text, fileName });
  const input = { text, fileName, document };

  if (customer === 'ollies') return parseOllies(input);
  if (customer === 'carnival') return parseCarnival(input);
  if (customer === 'tenbelow') return parseTenBelow(input);
  if (customer === 'bealls') return parseBealls(input);
  if (customer === 'gabes') return parseGabes(input);
  if (customer === 'spencers') return parseSpencers(input);
  if (customer === 'cititrends') return parseCitiTrends(input);
  if (customer === 'shoeshow') return parseShoeShow(input);
  if (customer === 'variety') return parseVariety(input);
  return genericParsedDocument();
}

function addQuality(parsed) {
  const header = parsed.header || {};
  const lines = parsed.lines || [];

  const headerMissing = missingFields(header, ['order_no', 'customer_code', 'store_code', 'terms_code', 'division_code', 'warehouse_code']);
  const lineMissing = [];
  for (const line of lines) {
    const missing = missingFields(line, ['style_code', 'color_code', 'warehouse_code', 'qty_sz1']);
    if (missing.length) lineMissing.push({ line_no: line.line_no, missing });
    line.missing_fields = missing;
  }

  if (!lines.length) {
    lineMissing.push({ line_no: null, missing: ['no_lines_extracted'] });
  }

  parsed.header.missing_fields = headerMissing;
  parsed.status = inferStatus({ headerMissing, lineMissing, conflicts: parsed.conflicts || [] });
  parsed.needs_mapping = {
    header: headerMissing,
    lines: lineMissing,
    conflicts: parsed.conflicts || []
  };
  return parsed;
}

export function parsePurchaseOrder({ text, fileName, document }) {
  const rawParsed = parseRawPurchaseOrder({ text, fileName, document });
  return addQuality(enrichOrderWithMasters(normalizeForA2000(rawParsed)));
}
