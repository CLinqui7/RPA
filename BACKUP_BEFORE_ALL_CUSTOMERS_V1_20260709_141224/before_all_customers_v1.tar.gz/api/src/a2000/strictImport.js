function clean(value) {
  if (value === null || value === undefined) return '';
  return String(value).trim();
}

function finiteNumber(value) {
  const raw = clean(value);
  if (!raw) return null;
  const parsed = Number(raw);
  return Number.isFinite(parsed) ? parsed : null;
}

export function explicitQtyBucketEntries(line = {}) {
  return Array.from({ length: 18 }, (_, index) => {
    const bucket = index + 1;
    const value = line[`qty_sz${bucket}`];
    return { bucket, value };
  });
}

export function hasExplicitA2000QtyBucket(line = {}) {
  return explicitQtyBucketEntries(line).some(({ value }) => clean(value) !== '');
}

export function invalidA2000QtyBuckets(line = {}) {
  return explicitQtyBucketEntries(line)
    .filter(({ value }) => clean(value) !== '')
    .filter(({ value }) => {
      const parsed = finiteNumber(value);
      return parsed === null || !Number.isInteger(parsed) || parsed < 0;
    });
}

export function hasPositiveA2000QtyBucket(line = {}) {
  if (invalidA2000QtyBuckets(line).length) return false;
  return explicitQtyBucketEntries(line).some(({ value }) => {
    const parsed = finiteNumber(value);
    return parsed !== null && parsed > 0;
  });
}

export function applyExplicitA2000QtyBuckets(row, line = {}) {
  for (const { bucket, value } of explicitQtyBucketEntries(line)) {
    row[`QTY_SZ${bucket}`] = clean(value);
  }
  return row;
}

export function strictHeaderMissing(header = {}) {
  const required = [
    ['customer_code', header.customer_code],
    ['store_code', header.store_code],
    ['order_no', header.order_no],
    ['order_date', header.order_date],
    ['start_date', header.start_date],
    ['cancel_date', header.cancel_date],
    ['terms_code', header.terms_code],
    ['division_code', header.division_code],
    ['warehouse_code', header.warehouse_code]
  ];
  return required.filter(([, value]) => clean(value) === '').map(([field]) => field);
}

export function strictLineMissing(header = {}, line = {}) {
  const missing = [];
  if (!clean(line.line_no)) missing.push('line_no');
  if (!clean(line.style_code)) missing.push('style_code');
  if (!clean(line.color_code)) missing.push('color_code');

  const salesPriceRaw = clean(line.sales_price);
  if (!salesPriceRaw) missing.push('sales_price');
  else {
    const salesPrice = finiteNumber(salesPriceRaw);
    if (salesPrice === null || salesPrice < 0) missing.push('sales_price_invalid');
  }

  if (!clean(line.warehouse_code || header.warehouse_code)) missing.push('warehouse_code');
  if (invalidA2000QtyBuckets(line).length) missing.push('qty_szn_invalid');
  if (!hasPositiveA2000QtyBucket(line)) missing.push('qty_szn');
  return [...new Set(missing)];
}

export function isStrictA2000Header(header = {}) {
  return strictHeaderMissing(header).length === 0;
}

export function isStrictA2000Line(header = {}, line = {}) {
  return strictLineMissing(header, line).length === 0;
}
