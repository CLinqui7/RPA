import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { extractPdfTextFromBuffer } from './po/pdfText.js';
import { parsePurchaseOrder } from './po/parsers/index.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const API_ROOT = path.resolve(__dirname, '..');
const FIXTURE_ROOT = path.join(API_ROOT, 'training', 'all_customer_source_fixtures');

const FIXTURES = [
  { rel: '10 below/72041 American Exchange PO.pdf', parser: 'tenbelow', customer: '10BELOW' },
  { rel: 'ITSFASHION/stainless steel AMEX PO.pdf', parser: 'catocorp', customer: 'ITSFASHION', document: { subject: 'ITS FASHION PURCHASE ORDERS' } },
  { rel: 'MACYSBACKS/PO 4931768.pdf', parser: 'macysbacks', customer: 'MACYSBACKS' },
  { rel: 'MARSHALLS/hardcopie.PDF', parser: 'marshalls', customer: 'MARSHALLS' },
  { rel: 'MESALVEINC/reportPO-24027385.pdf', parser: 'mesalve', customer: 'MESALVEINC' },
  { rel: 'OLLIES/POLINK 1.pdf', parser: 'ollies', customer: 'OLLIES' },
  { rel: 'SHOE4500/hardcopie.PDF', parser: 'shoeshow', customer: 'SHOE4500' },
  { rel: 'TILLYS/hardcopie.pdf', parser: 'tillys', customer: 'TILLYS' },
  { rel: 'TJMAXX/60 089114.pdf', parser: 'tjmaxx', customer: 'TJMAXX' },
  { rel: 'VARIETYWHO/1885387.pdf', parser: 'variety', customer: 'VARIETYWHO' },
  { rel: 'Versona/615628 earlier ship.pdf', parser: 'catocorp', customer: 'VERSONA', document: { subject: 'VERSONA PO 615628' } },
  { rel: 'ZUMIEZ/4587_476085_20260204134804 LINKIN PARK 1.pdf', parser: 'zumiez', customer: 'ZUMIEZ' },
  { rel: 'beallsoutl/hardcopie nueva.pdf', parser: 'bealls', customer: 'BEALLSOUTL' },
  { rel: 'beallsoutl/hardcopie vieja.PDF', parser: 'bealls', customer: 'BEALLSOUTL' },
  { rel: 'citi/PurchaseOrder-0000199431-00-009721.pdf', parser: 'cititrends', customer: 'CITI' },
  { rel: 'colony/COLONY LINKEDIN.pdf', parser: 'colony', customer: 'COLONY' },
  { rel: 'gabrielbro/VendorCopy_13003334.pdf', parser: 'gabes', customer: 'GABRIELBRO' },
  { rel: 'ipc/IPC PO-GG-6026.pdf', parser: 'ipc', customer: 'IPC' },
  { rel: 'SPENCER/spencer.PDF', parser: 'spencers', customer: 'SPENCER' }
];

function conflictCodes(parsed) {
  return (parsed.conflicts || []).map((item) => item.code || item.field || 'unknown');
}

function warningCodes(parsed) {
  return (parsed.warnings || []).map((item) => item.code || item.field || 'unknown');
}

const results = [];
let failed = 0;

for (const fixture of FIXTURES) {
  const filePath = path.join(FIXTURE_ROOT, fixture.rel);
  try {
    const buffer = await fs.readFile(filePath);
    const text = await extractPdfTextFromBuffer(buffer);
    const fileName = path.basename(filePath);
    const document = { file_name: fileName, file_path: filePath, ...(fixture.document || {}) };
    const parsed = parsePurchaseOrder({ text, fileName, document });
    const parserOk = parsed.parser === fixture.parser;
    const customerOk = parsed.header?.customer_code === fixture.customer;
    if (!parserOk || !customerOk) failed += 1;
    results.push({
      source: fixture.rel,
      expected_parser: fixture.parser,
      actual_parser: parsed.parser,
      expected_customer: fixture.customer,
      actual_customer: parsed.header?.customer_code || null,
      parser_ok: parserOk,
      customer_ok: customerOk,
      order_no: parsed.header?.order_no || null,
      status: parsed.status || null,
      header_missing: parsed.needs_mapping?.header || [],
      line_count: (parsed.lines || []).length,
      line_missing: parsed.needs_mapping?.lines || [],
      conflict_codes: conflictCodes(parsed),
      warning_codes: warningCodes(parsed),
      totals: parsed.totals || {}
    });
  } catch (error) {
    failed += 1;
    results.push({ source: fixture.rel, expected_parser: fixture.parser, expected_customer: fixture.customer, result: 'ERROR', error: error.message });
  }
}

console.log(JSON.stringify({
  suite: 'ALL_CUSTOMER_SOURCE_HARDCOPY_AUDIT',
  source_pdf_count: FIXTURES.length,
  passed_identity_checks: FIXTURES.length - failed,
  failed_identity_checks: failed,
  results
}, null, 2));

if (failed) process.exitCode = 1;
