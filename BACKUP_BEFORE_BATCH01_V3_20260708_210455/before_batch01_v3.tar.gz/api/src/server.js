import express from 'express';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import cors from 'cors';
import { config } from './config.js';
import { runScan } from './runScan.js';
import { listEvents, markEvent } from './runRepository.js';
import { listDocuments } from './documentRepository.js';
import { extractPdfTextFromBuffer } from './po/pdfText.js';
import { parsePurchaseOrder } from './po/parsers/index.js';
import { supabase } from './supabase.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const API_ROOT = path.resolve(__dirname, '..');
const PROJECT_ROOT = path.resolve(__dirname, '..', '..');

const app = express();
const DEFAULT_INVOICE_SUBJECT_FILTER = process.env.INVOICE_SUBJECT_FILTER || config.invoiceSubjectFilter || 'factura american';

const corsOptions = {
  origin: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
};

app.use(cors(corsOptions));
app.options('*', cors(corsOptions));
app.use(express.json());

const EXPORTS_DIR = path.join(API_ROOT, 'exports');
app.use('/exports', express.static(EXPORTS_DIR));

function normalizeForFilter(value = '') {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

function subjectMatchesFilter(event = {}, filter = DEFAULT_INVOICE_SUBJECT_FILTER) {
  const normalizedFilter = normalizeForFilter(filter);
  if (!normalizedFilter) return true;

  const alternatives = normalizedFilter.split('|').map(part => part.trim()).filter(Boolean);
  const analysis = event.raw?.analysis || event.analysis || {};
  const subjectHaystack = normalizeForFilter([
    event.subject,
    analysis.cleanSubject,
    analysis.displayTitle
  ].filter(Boolean).join(' '));

  return alternatives.some(item => subjectHaystack.includes(item));
}

app.get('/health', (_req, res) => {
  res.json({
    ok: true,
    service: 'outlook-rpa-api',
    port: config.port,
    outlookHeadless: config.outlookHeadless,
    invoiceSubjectFilter: DEFAULT_INVOICE_SUBJECT_FILTER
  });
});

function candidateTestPdfDirs() {
  const candidates = [];
  if (process.env.A2000_TEST_PDF_DIR) candidates.push(path.resolve(process.env.A2000_TEST_PDF_DIR));

  // The API may be launched from repo root, /api, or by npm --prefix.
  // Use file location as the anchor so the web lab never searches only /api/test-pdfs.
  candidates.push(path.resolve(PROJECT_ROOT, 'test-pdfs'));
  candidates.push(path.resolve(API_ROOT, 'test-pdfs'));
  candidates.push(path.resolve(process.cwd(), 'test-pdfs'));
  candidates.push(path.resolve(process.cwd(), '..', 'test-pdfs'));
  candidates.push(path.resolve(process.cwd(), '..', '..', 'test-pdfs'));

  return [...new Set(candidates)];
}

async function getExistingTestPdfDir() {
  const candidates = candidateTestPdfDirs();
  for (const dir of candidates) {
    try {
      const stat = await fs.stat(dir);
      if (stat.isDirectory()) return dir;
    } catch {
      // Try next candidate.
    }
  }

  const error = new Error(`No se encontró carpeta test-pdfs. Buscado en: ${candidates.join(', ')}`);
  error.searchedDirs = candidates;
  throw error;
}

async function listTestPdfFiles() {
  const dir = await getExistingTestPdfDir();
  const entries = await fs.readdir(dir, { withFileTypes: true });
  const files = entries
    .filter(entry => entry.isFile() && /\.pdf$/i.test(entry.name))
    .map(entry => path.join(dir, entry.name))
    .sort((a, b) => path.basename(a).localeCompare(path.basename(b)));
  return { dir, files };
}

function compactLine(line = {}) {
  return {
    line_no: line.line_no,
    customer_sku: line.customer_sku || null,
    ticket_sku: line.ticket_sku || null,
    customer_upc: line.customer_upc || null,
    master_upc: line.master_upc || null,
    internal_sku: line.internal_sku || line.master_sku || null,
    style_raw: line.style_raw || null,
    style_code: line.style_code || null,
    color_raw: line.color_raw || null,
    color_code: line.color_code || null,
    description: line.description || null,
    list_price: line.list_price ?? null,
    sales_price: line.sales_price ?? null,
    master_price: line.master_price ?? null,
    qty_total: line.qty_total ?? null,
    warehouse_code: line.warehouse_code || null,
    size_raw: line.size_raw || line.size_code || null,
    missing_fields: line.missing_fields || [],
    raw: line.raw || {},
    master_candidates: {
      style: line.raw?.style_master_candidates || [],
      color: line.raw?.color_master_candidates || [],
      upc: line.raw?.upc_master_candidates || []
    }
  };
}


function alpha3ColorCode(value = '') {
  return /^[A-Z]{3}$/.test(String(value || '').trim().toUpperCase());
}

function normalizedColorText(value = '') {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, ' ')
    .trim();
}

function uniqueRows(rows = []) {
  const seen = new Set();
  const out = [];
  for (const row of rows || []) {
    const key = `${row.style || ''}|${row.color || ''}|${row.sku || ''}`;
    if (!seen.has(key)) {
      seen.add(key);
      out.push(row);
    }
  }
  return out;
}

function pickColorCandidateForCiti(line = {}) {
  const raw = line.raw || {};
  const candidates = uniqueRows([
    ...(raw.color_master_candidates || []),
    ...(raw.style_master_candidates || [])
  ].filter(row => row && row.color));
  if (!candidates.length) return null;

  const colorText = normalizedColorText(line.color_raw || line.description || '');
  const byCode = new Map(candidates.map(row => [String(row.color || '').trim().toUpperCase(), row]));

  const prefer = (...codes) => {
    for (const code of codes) {
      const found = byCode.get(String(code).toUpperCase());
      if (found) return found;
    }
    return null;
  };

  // Reglas aprobadas para Citi. Primero intentamos códigos alfabéticos de 3 letras.
  if (colorText.includes('BLACK OFF BLACK') || colorText.includes('BLACKOFFBLACK')) {
    return prefer('BKA', 'BCB') || candidates.find(row => alpha3ColorCode(row.color)) || candidates.find(row => /BLACK/i.test(row.color_description || '')) || candidates[0];
  }
  if (colorText.includes('BLACK')) {
    return prefer('BKA', 'BCB') || candidates.find(row => alpha3ColorCode(row.color)) || candidates.find(row => /BLACK/i.test(row.color_description || '')) || candidates[0];
  }
  if (colorText.includes('WHITE')) {
    return prefer('WTB', 'WHA') || candidates.find(row => alpha3ColorCode(row.color)) || candidates.find(row => /WHITE/i.test(row.color_description || '')) || candidates[0];
  }
  if (colorText.includes('PINK')) {
    return prefer('PKA') || candidates.find(row => alpha3ColorCode(row.color)) || candidates.find(row => /PINK/i.test(row.color_description || '')) || candidates[0];
  }
  if (colorText.includes('TAUPE')) {
    return prefer('TA2', 'TUA', 'TPE') || candidates.find(row => alpha3ColorCode(row.color)) || candidates.find(row => /TAUPE/i.test(row.color_description || '')) || candidates[0];
  }

  // Regla general: si el PDF trae color en texto y hay códigos alfabéticos de 3 letras,
  // usar uno validado por el master. Si hay varios, escoger el primero del master para no frenar el flujo.
  return candidates.find(row => alpha3ColorCode(row.color)) || candidates[0];
}

function removeSatisfiedMissing(parsed) {
  const header = parsed.header || {};
  const lines = parsed.lines || [];
  const needs = parsed.needs_mapping || { header: [], lines: [], conflicts: [] };

  const headerMissing = (needs.header || []).filter(field => {
    if (header[field]) return false;
    return true;
  });

  const lineMissing = (needs.lines || []).map(entry => {
    const line = lines.find(item => String(item.line_no) === String(entry.line_no)) || {};
    const missing = (entry.missing || []).filter(field => {
      if (field === 'master_upc' && (line.master_upc || line.customer_upc || line.ticket_sku)) return false;
      if (field === 'upc' && (line.master_upc || line.customer_upc || line.ticket_sku)) return false;
      if (line[field]) return false;
      return true;
    });
    return { ...entry, missing };
  }).filter(entry => (entry.missing || []).length > 0);

  parsed.needs_mapping = {
    ...needs,
    header: headerMissing,
    lines: lineMissing,
    conflicts: needs.conflicts || []
  };

  for (const line of lines) {
    const missing = lineMissing.find(entry => String(entry.line_no) === String(line.line_no));
    line.missing_fields = missing?.missing || [];
  }

  if (!headerMissing.length && !lineMissing.length && !(parsed.needs_mapping.conflicts || []).length) {
    parsed.status = 'parsed';
  }
  return parsed;
}

function finalizeLabParsed(parsed = {}) {
  const header = parsed.header || {};
  const isCiti = String(header.customer_code || parsed.customer_code || '').toUpperCase() === 'CITI' || parsed.parser === 'cititrends';
  if (!isCiti) return removeSatisfiedMissing(parsed);

  header.customer_code = header.customer_code || 'CITI';
  header.store_code = header.store_code || 'SAME';
  header.warehouse_code = header.warehouse_code || 'PE';
  parsed.header = header;

  for (const line of parsed.lines || []) {
    line.warehouse_code = line.warehouse_code || header.warehouse_code || 'PE';

    if (!line.style_code) {
      const styleCandidates = line.raw?.style_master_candidates || [];
      if (styleCandidates[0]?.style) {
        line.style_code = styleCandidates[0].style;
        line.raw = { ...(line.raw || {}), style_match_rule: 'citi_first_master_candidate' };
      }
    }

    if (!line.color_code) {
      const chosen = pickColorCandidateForCiti(line);
      if (chosen?.color) {
        line.color_code = String(chosen.color).trim();
        line.internal_sku = line.internal_sku || chosen.sku || (line.style_code ? `${line.style_code}${line.color_code}` : null);
        line.master_price = line.master_price ?? chosen.price ?? null;
        line.raw = {
          ...(line.raw || {}),
          color_match_rule: alpha3ColorCode(chosen.color) ? 'citi_alpha3_or_customer_preference' : 'citi_first_valid_master_candidate',
          color_match_family: normalizedColorText(line.color_raw || line.description || ''),
          color_match_confidence: alpha3ColorCode(chosen.color) ? 0.95 : 0.80,
          color_chosen_candidate: chosen
        };
      }
    }

    // Citi trae UPC de factura. Si el UPC master no se puede decidir por talla, no bloqueamos la orden.
    // Guardamos el UPC del PDF como fallback operativo, con trazabilidad.
    if (!line.master_upc && (line.customer_upc || line.ticket_sku)) {
      line.master_upc = line.customer_upc || line.ticket_sku;
      line.raw = {
        ...(line.raw || {}),
        upc_match_rule: 'citi_invoice_upc_used_when_master_upc_ambiguous',
        upc_source: 'invoice_customer_upc'
      };
    }
  }

  return removeSatisfiedMissing(parsed);
}

function compactParsed(file, parsed, elapsedMs = null) {
  parsed = finalizeLabParsed(parsed);
  return {
    file,
    file_name: path.basename(file),
    parser: parsed.parser,
    status: parsed.status,
    confidence: parsed.confidence ?? null,
    elapsed_ms: elapsedMs,
    header: parsed.header || {},
    totals: parsed.totals || {},
    missing: parsed.needs_mapping || { header: [], lines: [], conflicts: [] },
    conflicts: parsed.conflicts || [],
    master_lookup: parsed.raw_enrichment?.master_lookup || null,
    line_count: parsed.lines?.length || 0,
    lines: (parsed.lines || []).map(compactLine),
    parsed_raw: parsed
  };
}


const A2000_HEADER_COLUMNS = [
  'SEQ_ORDER_NO','CUST_NO','STORE_NO','ORDER_NO','ORDER_DATE','START_DATE','CANCEL_DATE','BOOK_DATE','CUST_DEPT','REGION','DC_NO','DIV_NO','BOOK_SEASON','SHIP_VIA_NO','PRIORITY','TERM_NO','DISC_CODE','FACTOR_NO','FACTOR_APPR_NO','SMAN1_NO','SMAN2_NO','SMAN3_NO','SMAN1_COMM','SMAN2_COMM','SMAN3_COMM','USER_REF1','USER_REF2','BACK_ORDER','MASTER_INVOICE','REORDER','TAG','ORDER_ALIAS','CURRENCY','EXCHANGE_RATE','USER_REF3','USER_REF4','USER_REF5','DEF_WHOUSE','SH_RULE','FIRST_COST_RULE','PRICE_LIST_ID','PROMO_CODE','ORDER_TYPE','ORDER_HOLD','EVENT_DATE','SALES_TAX1','SALES_TAX2','SALES_TAX1L','TAX_AUTH'
];

const A2000_LINE_COLUMNS = [
  'SEQ_ORDER_NO','LINE_NO','CUST_NO','_NO','ORDER_NO','STYLE','COLOR_NO','SALES_PRICE','WHOUSE','QTY_SZ1','QTY_SZ2','QTY_SZ3','QTY_SZ4','QTY_SZ5','QTY_SZ6','QTY_SZ7','QTY_SZ8','QTY_SZ9','QTY_SZ10','QTY_SZ11','QTY_SZ12','QTY_SZ13','QTY_SZ14','QTY_SZ15','QTY_SZ16','QTY_SZ17','QTY_SZ18','SIZE_NO','CUST_STYLE1','CUST_STYLE2','SUB_STYLE','SUB_COLOR_NO','REF','ORDER_ALIAS','LIST_PRICE','SMAN1_NO','SMAN2_NO','SMAN3_NO','SMAN1_COMM','SMAN2_COMM','SMAN3_COMM'
];

function csvEscape(value) {
  if (value === null || value === undefined) return '';
  const text = String(value);
  if (/[",\n\r]/.test(text)) return `"${text.replaceAll('"', '""')}"`;
  return text;
}

function rowsToCsv(columns, rows) {
  return [
    columns.map(csvEscape).join(','),
    ...rows.map(row => columns.map(column => csvEscape(row[column] ?? '')).join(','))
  ].join('\n');
}

function cleanExportValue(value) {
  if (value === null || value === undefined) return '';
  return String(value).trim();
}

function trimExport(value, max = 20) {
  return cleanExportValue(value).slice(0, max);
}

function formatA2000Date(value) {
  const raw = cleanExportValue(value);
  if (!raw) return '';
  if (/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(raw)) return raw;
  if (/^\d{4}-\d{2}-\d{2}/.test(raw)) {
    const [yyyy, mm, dd] = raw.slice(0, 10).split('-');
    return `${Number(mm)}/${Number(dd)}/${yyyy}`;
  }
  return raw;
}

function blankExportRow(columns) {
  return Object.fromEntries(columns.map(column => [column, '']));
}

function a2000HeaderRowFromParsed(item) {
  const h = item.header || {};
  const row = blankExportRow(A2000_HEADER_COLUMNS);
  row.CUST_NO = cleanExportValue(h.customer_code);
  row.STORE_NO = cleanExportValue(h.store_code);
  row.ORDER_NO = cleanExportValue(h.order_no);
  row.ORDER_DATE = formatA2000Date(h.order_date);
  row.START_DATE = formatA2000Date(h.start_date);
  row.CANCEL_DATE = formatA2000Date(h.cancel_date);
  row.BOOK_DATE = formatA2000Date(h.book_date || h.order_date);
  row.CUST_DEPT = cleanExportValue(h.dept_code || h.dept_raw);
  row.DIV_NO = cleanExportValue(h.division_code);
  row.SHIP_VIA_NO = cleanExportValue(h.ship_via_code);
  row.TERM_NO = cleanExportValue(h.terms_code);
  row.USER_REF1 = trimExport(h.order_no || item.file_name, 20);
  row.USER_REF2 = trimExport(item.subject || h.terms_raw || '', 20);
  row.USER_REF3 = trimExport(item.status, 20);
  row.MASTER_INVOICE = 'Y';
  row.DEF_WHOUSE = cleanExportValue(h.warehouse_code || 'PE');
  return row;
}

function a2000LineRowFromParsed(item, line) {
  const h = item.header || {};
  const row = blankExportRow(A2000_LINE_COLUMNS);
  row.LINE_NO = cleanExportValue(line.line_no);
  row.CUST_NO = cleanExportValue(h.customer_code);
  row._NO = cleanExportValue(h.store_code);
  row.ORDER_NO = cleanExportValue(h.order_no);
  row.STYLE = cleanExportValue(line.style_code);
  row.COLOR_NO = cleanExportValue(line.color_code);
  row.SALES_PRICE = cleanExportValue(line.sales_price);
  row.WHOUSE = cleanExportValue(line.warehouse_code || h.warehouse_code || 'PE');
  row.QTY_SZ1 = cleanExportValue(line.qty_sz1 ?? line.quantity ?? line.qty_total);
  row.SIZE_NO = cleanExportValue(line.size_raw || line.size_code);
  row.CUST_STYLE1 = trimExport(line.customer_sku, 20);
  row.CUST_STYLE2 = trimExport(line.customer_upc || line.ticket_sku || line.master_upc, 20);
  row.REF = trimExport(line.customer_upc || line.ticket_sku || item.file_name, 15);
  row.LIST_PRICE = cleanExportValue(line.list_price);
  return row;
}

function buildA2000ExportRows(results = []) {
  const importable = (results || []).filter(item => item.status === 'parsed' && item.header?.customer_code && item.header?.order_no);
  const headerRows = importable.map(a2000HeaderRowFromParsed);
  const lineRows = [];
  for (const item of importable) {
    for (const line of item.lines || []) {
      if (!line.style_code || !line.color_code) continue;
      lineRows.push(a2000LineRowFromParsed(item, line));
    }
  }
  return { importable, headerRows, lineRows };
}

function exportUrlFor(filePath) {
  return `/exports/${path.basename(filePath)}`;
}

async function ensureExportsDirLocal() {
  await fs.mkdir(EXPORTS_DIR, { recursive: true });
  return EXPORTS_DIR;
}

async function parseDocumentsForExport(req, source) {
  if (source === 'test') {
    const requested = Array.isArray(req.body?.files) ? req.body.files : null;
    const discovered = requested?.length ? null : await listTestPdfFiles();
    const files = requested?.length
      ? requested.map(file => path.isAbsolute(file) ? file : path.resolve(PROJECT_ROOT, file))
      : discovered.files;
    const results = [];
    for (const file of files) {
      const started = Date.now();
      try {
        const buffer = await fs.readFile(file);
        const text = await extractPdfTextFromBuffer(buffer);
        const parsed = parsePurchaseOrder({ text, fileName: path.basename(file), document: { file_name: path.basename(file), file_path: file }});
        results.push(compactParsed(file, parsed, Date.now() - started));
      } catch (error) {
        results.push({ file, file_name: path.basename(file), status: 'error', error: error.message, elapsed_ms: Date.now() - started });
      }
    }
    return results;
  }

  const requestedIds = Array.isArray(req.body?.ids) ? new Set(req.body.ids.map(String)) : null;
  const documents = (await listInvoiceDocuments(req)).filter(doc => !requestedIds || requestedIds.has(String(doc.id)));
  const results = [];
  for (const doc of documents) {
    const started = Date.now();
    try {
      const loaded = await readBufferForStoredDocument(doc);
      const text = await extractPdfTextFromBuffer(loaded.buffer);
      const parsed = parsePurchaseOrder({
        text,
        fileName: doc.file_name,
        document: { id: doc.id, file_name: doc.file_name, file_path: loaded.path, storage_bucket: doc.storage_bucket, storage_path: doc.storage_path, subject: doc.subject, sender_email: doc.sender_email, source: doc.source }
      });
      results.push({
        ...compactParsed(loaded.path, parsed, Date.now() - started),
        source: 'email_document',
        document_id: doc.id,
        subject: doc.subject,
        sender_name: doc.sender_name,
        sender_email: doc.sender_email,
        created_at: doc.created_at,
        storage_bucket: doc.storage_bucket,
        storage_path: doc.storage_path,
        local_path: doc.raw?.localPath || null,
        file_load_source: loaded.source
      });
    } catch (error) {
      results.push({ source: 'email_document', document_id: doc.id, file_name: doc.file_name, subject: doc.subject, sender_email: doc.sender_email, status: 'error', error: error.message, elapsed_ms: Date.now() - started });
    }
  }
  return results;
}

async function safeReadPdfFromQuery(req) {
  const documentId = String(req.query.document_id || '').trim();
  if (documentId) {
    const docs = await listDocuments({ limit: 500 });
    const doc = docs.find(item => String(item.id) === documentId);
    if (!doc) throw new Error('Documento no encontrado en Supabase/documents');
    const loaded = await readBufferForStoredDocument(doc);
    return { ...loaded, fileName: doc.file_name || 'factura.pdf' };
  }

  const rawFile = String(req.query.file || '').trim();
  if (!rawFile) throw new Error('Falta document_id o file');
  const resolved = path.isAbsolute(rawFile) ? rawFile : path.resolve(PROJECT_ROOT, rawFile);
  const allowedRoots = [PROJECT_ROOT, API_ROOT].map(root => path.resolve(root));
  if (!allowedRoots.some(root => resolved.startsWith(root))) throw new Error('Ruta de PDF no permitida');
  return { buffer: await fs.readFile(resolved), source: 'local_file', path: resolved, fileName: path.basename(resolved) };
}

app.get('/po/pdf-preview', async (req, res) => {
  try {
    const loaded = await safeReadPdfFromQuery(req);
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="${String(loaded.fileName || 'factura.pdf').replaceAll('"', '')}"`);
    res.send(loaded.buffer);
  } catch (error) {
    res.status(404).json({ ok: false, error: error.message });
  }
});

app.post('/po/export-a2000-import', async (req, res) => {
  try {
    const source = String(req.query.source || req.body?.source || 'email') === 'test' ? 'test' : 'email';
    const results = await parseDocumentsForExport(req, source);
    const { importable, headerRows, lineRows } = buildA2000ExportRows(results);
    const timestamp = new Date().toISOString().replace(/[-:.TZ]/g, '').slice(0, 14);
    const exportDir = await ensureExportsDirLocal();
    const headerFileName = `A2000_IMPORT_HEADERS_${source}_${timestamp}.csv`;
    const linesFileName = `A2000_IMPORT_SALES_LINES_${source}_${timestamp}.csv`;
    const headerPath = path.join(exportDir, headerFileName);
    const linesPath = path.join(exportDir, linesFileName);
    await fs.writeFile(headerPath, rowsToCsv(A2000_HEADER_COLUMNS, headerRows), 'utf8');
    await fs.writeFile(linesPath, rowsToCsv(A2000_LINE_COLUMNS, lineRows), 'utf8');
    res.json({
      ok: true,
      source,
      generated_at: new Date().toISOString(),
      parsed_count: results.length,
      importable_count: importable.length,
      header_rows_count: headerRows.length,
      line_rows_count: lineRows.length,
      skipped_count: results.length - importable.length,
      header_file_name: headerFileName,
      lines_file_name: linesFileName,
      header_url: exportUrlFor(headerPath),
      lines_url: exportUrlFor(linesPath),
      columns: { headers: A2000_HEADER_COLUMNS, lines: A2000_LINE_COLUMNS },
      preview: { headers: headerRows.slice(0, 5), lines: lineRows.slice(0, 10) },
      skipped: results.filter(item => !importable.includes(item)).map(item => ({ file_name: item.file_name, status: item.status, missing: item.missing, error: item.error || null }))
    });
  } catch (error) {
    res.status(500).json({ ok: false, error: error.message });
  }
});


app.get('/po/test-pdfs', async (_req, res) => {
  try {
    const { dir, files } = await listTestPdfFiles();
    res.json({
      ok: true,
      dir,
      searched_dirs: candidateTestPdfDirs(),
      count: files.length,
      files: files.map(file => ({ file, file_name: path.basename(file) }))
    });
  } catch (error) {
    res.status(500).json({ ok: false, searched_dirs: error.searchedDirs || candidateTestPdfDirs(), error: error.message });
  }
});

app.post('/po/parse-test-pdfs', async (req, res) => {
  try {
    const requested = Array.isArray(req.body?.files) ? req.body.files : null;
    const discovered = requested?.length ? null : await listTestPdfFiles();
    const files = requested?.length
      ? requested.map(file => path.isAbsolute(file) ? file : path.resolve(PROJECT_ROOT, file))
      : discovered.files;

    const results = [];
    for (const file of files) {
      const started = Date.now();
      try {
        const buffer = await fs.readFile(file);
        const text = await extractPdfTextFromBuffer(buffer);
        const parsed = parsePurchaseOrder({
          text,
          fileName: path.basename(file),
          document: { file_name: path.basename(file), file_path: file }
        });
        results.push(compactParsed(file, parsed, Date.now() - started));
      } catch (error) {
        results.push({ file, file_name: path.basename(file), status: 'error', error: error.message, elapsed_ms: Date.now() - started });
      }
    }

    res.json({
      ok: true,
      dir: discovered?.dir || null,
      searched_dirs: candidateTestPdfDirs(),
      count: results.length,
      generated_at: new Date().toISOString(),
      results
    });
  } catch (error) {
    res.status(500).json({ ok: false, searched_dirs: error.searchedDirs || candidateTestPdfDirs(), error: error.message });
  }
});


function documentLooksInScope(doc = {}, filter = DEFAULT_INVOICE_SUBJECT_FILTER) {
  const normalizedFilter = normalizeForFilter(filter);
  if (!normalizedFilter) return true;
  const alternatives = normalizedFilter.split('|').map(part => part.trim()).filter(Boolean);
  const haystack = normalizeForFilter([
    doc.subject,
    doc.file_name,
    doc.sender_name,
    doc.sender_email,
    doc.raw?.filter,
    doc.raw?.fallbackName,
    doc.raw?.suggestedName,
    doc.raw?.original_external_key
  ].filter(Boolean).join(' '));
  return alternatives.some(item => haystack.includes(item));
}

async function listInvoiceDocuments(req) {
  const showAll = String(req.query?.all || '') === '1';
  const subjectFilter = String(req.query?.subject || DEFAULT_INVOICE_SUBJECT_FILTER);
  const limit = Number(req.query?.limit || 200);
  const docs = await listDocuments({ limit });
  const scoped = showAll ? docs : docs.filter(doc => documentLooksInScope(doc, subjectFilter));
  return scoped.map(doc => ({
    ...doc,
    dashboard_scope: showAll ? 'all_documents' : 'invoice_subject_filter',
    dashboard_subject_filter: subjectFilter,
    local_path: doc.raw?.localPath || null
  }));
}

async function readBufferForStoredDocument(doc) {
  const localPath = doc.raw?.localPath || doc.local_path || null;
  if (localPath) {
    try {
      return { buffer: await fs.readFile(localPath), source: 'local_download', path: localPath };
    } catch {
      // Fall back to Supabase Storage below.
    }
  }

  if (doc.storage_bucket && doc.storage_path) {
    const { data, error } = await supabase.storage.from(doc.storage_bucket).download(doc.storage_path);
    if (error) throw error;
    const arrayBuffer = await data.arrayBuffer();
    return { buffer: Buffer.from(arrayBuffer), source: 'supabase_storage', path: `${doc.storage_bucket}/${doc.storage_path}` };
  }

  throw new Error(`No se encontró archivo local ni storage_path para ${doc.file_name || doc.id}`);
}

app.get('/po/email-documents', async (req, res) => {
  try {
    const documents = await listInvoiceDocuments(req);
    res.json({
      ok: true,
      subject_filter: String(req.query?.subject || DEFAULT_INVOICE_SUBJECT_FILTER),
      count: documents.length,
      documents
    });
  } catch (error) {
    res.status(500).json({ ok: false, error: error.message });
  }
});

app.post('/po/parse-email-documents', async (req, res) => {
  try {
    const requestedIds = Array.isArray(req.body?.ids) ? new Set(req.body.ids.map(String)) : null;
    const documents = (await listInvoiceDocuments(req)).filter(doc => !requestedIds || requestedIds.has(String(doc.id)));
    const results = [];

    for (const doc of documents) {
      const started = Date.now();
      try {
        const loaded = await readBufferForStoredDocument(doc);
        const text = await extractPdfTextFromBuffer(loaded.buffer);
        const parsed = parsePurchaseOrder({
          text,
          fileName: doc.file_name,
          document: {
            id: doc.id,
            file_name: doc.file_name,
            file_path: loaded.path,
            storage_bucket: doc.storage_bucket,
            storage_path: doc.storage_path,
            subject: doc.subject,
            sender_email: doc.sender_email,
            source: doc.source
          }
        });
        results.push({
          ...compactParsed(loaded.path, parsed, Date.now() - started),
          source: 'email_document',
          document_id: doc.id,
          subject: doc.subject,
          sender_name: doc.sender_name,
          sender_email: doc.sender_email,
          created_at: doc.created_at,
          storage_bucket: doc.storage_bucket,
          storage_path: doc.storage_path,
          local_path: doc.raw?.localPath || null,
          file_load_source: loaded.source
        });
      } catch (error) {
        results.push({
          source: 'email_document',
          document_id: doc.id,
          file: doc.raw?.localPath || doc.storage_path || doc.file_name,
          file_name: doc.file_name,
          subject: doc.subject,
          sender_email: doc.sender_email,
          status: 'error',
          error: error.message,
          elapsed_ms: Date.now() - started
        });
      }
    }

    res.json({
      ok: true,
      subject_filter: String(req.query?.subject || DEFAULT_INVOICE_SUBJECT_FILTER),
      count: results.length,
      generated_at: new Date().toISOString(),
      results
    });
  } catch (error) {
    res.status(500).json({ ok: false, error: error.message });
  }
});

app.get('/documents', async (_req, res) => {
  try {
    res.json(await listDocuments());
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/events', async (req, res) => {
  try {
    const showAll = String(req.query.all || '') === '1';
    const subjectFilter = String(req.query.subject || DEFAULT_INVOICE_SUBJECT_FILTER);
    const limit = Number(req.query.limit || 500);
    const events = await listEvents({ limit });
    const filtered = showAll ? events : events.filter(event => subjectMatchesFilter(event, subjectFilter));

    res.json(filtered.map(event => ({
      ...event,
      dashboard_scope: showAll ? 'all_email_events' : 'invoice_subject_filter',
      dashboard_subject_filter: subjectFilter
    })));
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/events/:id/status', async (req, res) => {
  try {
    const { status } = req.body;
    if (!['new', 'reviewed', 'closed'].includes(status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }
    res.json(await markEvent(req.params.id, status));
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

let running = false;

app.post('/run-scan', async (_req, res) => {
  if (running) return res.status(409).json({ error: 'RPA already running' });

  running = true;
  try {
    const result = await runScan();
    res.json({
      ...result,
      scope: {
        subject_filter: DEFAULT_INVOICE_SUBJECT_FILTER,
        note: 'El scanner descarga/guarda solo correos recibidos cuyo asunto coincide con este filtro.'
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  } finally {
    running = false;
  }
});

app.listen(config.port, () => {
  console.log(`API running on http://localhost:${config.port}`);
  console.log(`Invoice subject filter: ${DEFAULT_INVOICE_SUBJECT_FILTER}`);
});
