import fs from 'node:fs/promises';
import path from 'node:path';
import { extractPdfTextFromBuffer } from './po/pdfText.js';
import { parsePurchaseOrder } from './po/parsers/index.js';

const files = process.argv.slice(2);
if (!files.length) {
  console.error('Uso: node api/src/debug-inspect-enriched-pdf.js <pdf1> [pdf2 ...]');
  process.exit(1);
}

for (const file of files) {
  const buffer = await fs.readFile(file);
  const text = await extractPdfTextFromBuffer(buffer);
  const parsed = parsePurchaseOrder({
    text,
    fileName: path.basename(file),
    document: { file_name: path.basename(file) }
  });

  const summary = {
    file: path.basename(file),
    parser: parsed.parser,
    document_family: parsed.document_family || null,
    header: {
      customer_raw: parsed.header?.customer_raw ?? null,
      customer_code: parsed.header?.customer_code ?? null,
      order_no: parsed.header?.order_no ?? null,
      store_raw: parsed.header?.store_raw ?? null,
      store_code: parsed.header?.store_code ?? null,
      terms_raw: parsed.header?.terms_raw ?? null,
      terms_code: parsed.header?.terms_code ?? null,
      division_code: parsed.header?.division_code ?? null,
      warehouse_code: parsed.header?.warehouse_code ?? null
    },
    status: parsed.status,
    needs_mapping: parsed.needs_mapping,
    lines: (parsed.lines || []).map((line) => ({
      line_no: line.line_no,
      customer_sku_raw: line.raw?.customer_sku_raw ?? line.customer_sku ?? null,
      customer_upc_raw: line.raw?.customer_upc_raw ?? line.customer_upc ?? null,
      style_raw: line.style_raw ?? null,
      style_code: line.style_code ?? null,
      color_raw: line.color_raw ?? null,
      color_code: line.color_code ?? null,
      color_description: line.raw?.sku_master?.color_description ?? null,
      color_abbr: line.raw?.sku_master?.color_abbr ?? null,
      size_raw: line.size_raw ?? null,
      size_code: line.size_code ?? null,
      scale_code: line.scale_code ?? null,
      scale_abbr: line.scale_abbr ?? null,
      qty_total: line.qty_total ?? null,
      qty_sz1: line.qty_sz1 ?? null,
      sales_price: line.sales_price ?? null,
      list_price: line.list_price ?? null,
      warehouse_code: line.warehouse_code ?? null,
      division_code: line.master_division_code ?? line.division_code ?? null,
      resolution: line.raw?.upc_resolution || line.raw?.composite_style_resolution || null,
      style_master_override: line.raw?.style_master_override || null
    }))
  };

  console.log(JSON.stringify(summary, null, 2));
}
