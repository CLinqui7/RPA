import fs from 'node:fs';
import path from 'node:path';

const MASTER_DIR = process.env.A2000_MASTER_DIR || path.resolve(process.cwd(), 'api/masters');
const CACHE_DIR = process.env.A2000_MASTER_CACHE_DIR || path.join(MASTER_DIR, 'cache');
let cache = null;

function clean(value) {
  if (value === null || value === undefined) return '';
  return String(value).replace(/\u00a0/g, ' ').trim();
}

function norm(value) {
  return clean(value).toUpperCase().replace(/[^A-Z0-9]/g, '');
}

function normText(value) {
  return clean(value).toUpperCase().replace(/\s+/g, ' ');
}

function parseCsvLine(line) {
  const out = [];
  let current = '';
  let inQuotes = false;
  const value = String(line || '');
  for (let i = 0; i < value.length; i += 1) {
    const ch = value[i];
    const next = value[i + 1];
    if (ch === '"') {
      if (inQuotes && next === '"') {
        current += '"';
        i += 1;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (ch === ',' && !inQuotes) {
      out.push(current);
      current = '';
    } else {
      current += ch;
    }
  }
  out.push(current);
  return out.map(clean);
}

function readCompactCsv(fileName) {
  const filePath = path.join(CACHE_DIR, fileName);
  if (!fs.existsSync(filePath)) return [];
  const text = fs.readFileSync(filePath, 'utf8');
  const lines = text.split(/\r?\n/).filter((line) => clean(line));
  if (!lines.length) return [];
  const headers = parseCsvLine(lines[0]);
  return lines.slice(1).map((line) => {
    const values = parseCsvLine(line);
    const row = {};
    headers.forEach((header, index) => { row[header] = values[index] ?? ''; });
    return row;
  });
}

function emptyCache(error = null) {
  return {
    loaded: false,
    masterDir: MASTER_DIR,
    cacheDir: CACHE_DIR,
    error,
    counts: {},
    customerByCode: new Map(),
    customerByName: new Map(),
    storeByCustomerStore: new Map(),
    defaultStoreByCustomer: new Map(),
    skuByStyleColor: new Map(),
    skuByStyle: new Map(),
    styleByCustomerNorm: new Map(),
    upcByStyleColor: new Map(),
    upcByStyleColorSize: new Map(),
    colorByCode: new Map(),
    warehouseByCode: new Map()
  };
}

function addToSetMap(map, key, value) {
  if (!key || !value) return;
  if (!map.has(key)) map.set(key, new Set());
  map.get(key).add(value);
}

function buildFromCompactCsv() {
  const manifestPath = path.join(CACHE_DIR, 'manifest.json');
  if (!fs.existsSync(manifestPath)) {
    return emptyCache(`Compact master cache not found. Build it with: python3 api/scripts/build-master-cache.py ${MASTER_DIR}`);
  }

  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  const customers = readCompactCsv('customers.csv');
  const stores = readCompactCsv('stores.csv');
  const skuRows = readCompactCsv('sku.csv');
  const upcRows = readCompactCsv('upc.csv');
  const colorRows = readCompactCsv('colors.csv');
  const warehouseRows = readCompactCsv('warehouses.csv');

  const customerByCode = new Map();
  const customerByName = new Map();
  for (const row of customers) {
    const code = clean(row.customer).toUpperCase();
    if (!code) continue;
    customerByCode.set(code, {
      Customer: code,
      'Cust Name': row.name,
      Terms: row.terms,
      'Terms Description': row.terms_description,
      'Ship Via': row.ship_via,
      'Def Wh': row.def_wh,
      Div: row.div,
      Active: row.active,
      'Addr 1': row.addr1,
      City: row.city,
      State: row.state,
      Postal: row.postal
    });
    if (row.name_norm && !customerByName.has(row.name_norm)) customerByName.set(row.name_norm, customerByCode.get(code));
  }

  const storeByCustomerStore = new Map();
  const storesByCustomer = new Map();
  for (const row of stores) {
    const customer = clean(row.customer).toUpperCase();
    const store = clean(row.store).toUpperCase();
    if (!customer || !store) continue;
    const rec = {
      Customer: customer,
      Store: store,
      'St Name': row.name,
      'St Addr 1': row.addr1,
      'St City': row.city,
      'St State': row.state,
      'St Postal': row.postal,
      'Ship Via': row.ship_via,
      Wh: row.wh,
      Active: row.active
    };
    storeByCustomerStore.set(`${customer}|${store}`, rec);
    if (!storesByCustomer.has(customer)) storesByCustomer.set(customer, []);
    storesByCustomer.get(customer).push(rec);
  }

  const defaultStoreByCustomer = new Map();
  for (const [customer, rows] of storesByCustomer.entries()) {
    const active = rows.filter((row) => clean(row.Active).toUpperCase() === 'Y');
    const preferred = active.find((row) => clean(row.Store).toUpperCase() === 'SAME')
      || active.find((row) => clean(row.Store).toUpperCase() === 'MASTR')
      || active[0]
      || rows.find((row) => clean(row.Store).toUpperCase() === 'SAME')
      || rows[0]
      || null;
    if (preferred) defaultStoreByCustomer.set(customer, preferred);
  }

  const skuByStyleColor = new Map();
  const skuByStyle = new Map();
  const styleByCustomerNormSets = new Map();
  for (const row of skuRows) {
    const style = clean(row.style).toUpperCase();
    const clr = clean(row.clr).toUpperCase();
    if (!style) continue;
    const rec = {
      Style: style,
      Clr: clr,
      'Style Descr': row.style_descr,
      'Clr Desc': row.clr_desc,
      'Clr Abbr': row.clr_abbr,
      Sku: row.sku,
      'Sku Descr': row.sku_descr,
      Scale: row.scale,
      'Scale Abbr': row.scale_abbr,
      Div: row.div,
      Customer: row.customer || 'STOCK',
      'Master Style': row.master_style,
      'Style Alias': row.style_alias,
      'Invoice Descr': row.invoice_descr,
      Price: row.price
    };
    if (style && clr && !skuByStyleColor.has(`${style}|${clr}`)) skuByStyleColor.set(`${style}|${clr}`, rec);
    if (!skuByStyle.has(style)) skuByStyle.set(style, []);
    skuByStyle.get(style).push(rec);
    const customer = clean(row.customer).toUpperCase() || 'STOCK';
    [row.style_norm, row.master_style_norm, row.style_alias_norm].filter(Boolean).forEach((token) => addToSetMap(styleByCustomerNormSets, `${customer}|${token}`, style));
  }
  const styleByCustomerNorm = new Map([...styleByCustomerNormSets.entries()].map(([key, set]) => [key, [...set]]));

  const upcByStyleColor = new Map();
  const upcByStyleColorSize = new Map();
  for (const row of upcRows) {
    const style = clean(row.style).toUpperCase();
    const clr = clean(row.clr).toUpperCase();
    if (!style || !clr) continue;
    const rec = {
      'Upc No': row.upc,
      Style: style,
      Clr: clr,
      'Size Name': row.size_name,
      'Size Num': row.size_num,
      Sku: row.sku,
      Div: row.div,
      Scale: row.scale,
      'Scale Abbr': row.scale_abbr
    };
    const key = `${style}|${clr}`;
    if (!upcByStyleColor.has(key)) upcByStyleColor.set(key, []);
    upcByStyleColor.get(key).push(rec);
    if (row.size_norm) {
      const sizeKey = `${style}|${clr}|${row.size_norm}`;
      if (!upcByStyleColorSize.has(sizeKey)) upcByStyleColorSize.set(sizeKey, []);
      upcByStyleColorSize.get(sizeKey).push(rec);
    }
  }

  const colorByCode = new Map();
  for (const row of colorRows) {
    const code = clean(row.code).toUpperCase();
    if (code) colorByCode.set(code, { 'Color Code': code, 'Color Abbr': row.abbr, 'Color Description': row.description, 'Nrf Color No': row.nrf, Active: row.active });
  }

  const warehouseByCode = new Map();
  for (const row of warehouseRows) {
    const code = clean(row.wh).toUpperCase();
    if (code) warehouseByCode.set(code, { Wh: code, 'Wh Name': row.name, 'Wh Type': row.type, 'Wh Addr 1': row.addr1, 'Wh Addr 2': row.addr2, 'Wh City': row.city, 'Wh State': row.state, 'Wh Postal': row.postal, 'Wh Country': row.country, 'Wh Active': row.active });
  }

  return {
    loaded: true,
    masterDir: MASTER_DIR,
    cacheDir: CACHE_DIR,
    counts: manifest.counts || {},
    customerByCode,
    customerByName,
    storeByCustomerStore,
    defaultStoreByCustomer,
    skuByStyleColor,
    skuByStyle,
    styleByCustomerNorm,
    upcByStyleColor,
    upcByStyleColorSize,
    colorByCode,
    warehouseByCode
  };
}

export function loadMasterData() {
  if (cache) return cache;
  try {
    cache = buildFromCompactCsv();
  } catch (error) {
    cache = emptyCache(error.message);
  }
  return cache;
}

export function normalizeMasterToken(value) {
  return norm(value);
}

export function cleanMasterValue(value) {
  return clean(value);
}

export function normalizeMasterText(value) {
  return normText(value);
}
